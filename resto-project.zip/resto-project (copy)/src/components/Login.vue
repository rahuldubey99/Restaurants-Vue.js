<template>
    <img class="logo" src="../assets/logo.png" alt="">
    <h1>Login</h1>
    <div class="register">
        <input type="text" name="email" id="email" v-model="email" placeholder="Enter email">
        <input type="password" name="password" id="password" v-model="password" placeholder="Enter password">
        <button v-on:click="login">Login</button>
        <p>
            <router-link to="/sign-up">Sign Up</router-link>
        </p>
    </div>
</template>
<script>
import axios from "axios";
export default {
    name:'Login-Page',
    data(){
        return {
            email:'',
            password:''
        }
    },
    methods:{
        async login(){
            let url = `http://localhost:3000/users?email=${this.email}&password=${this.password}`
            let result = await axios.get(url)

            if (result.status == 200 && result.data.length > 0) {
                localStorage.setItem("user-info",JSON.stringify(result.data[0]))
                this.$router.push({name:'Home'})
            }

        }
    },
    mounted(){
        let user = localStorage.getItem('user-info')
        if(user){
            this.$router.push({name:'Home'})
        }
    }
}

</script>

<style>
.logo{
    width: 100px;
}
.register input{
    width: 300px;
    height: 40px;
    padding-left: 20px;
    display: block;
    margin-bottom: 30px;
    margin-left: auto;
    margin-right: auto;
    border: 1px solid skyblue;

}
.register button{
    width: 320px;
    height: 40px;
    border: 1px solid skyblue;
    color: #fff;
    background-color: skyblue;
    cursor: pointer;
}
</style>