<template>
<Header />
<h1>Hello User, Welcome  on Add Restaurant Page </h1>
<form class="add">
    <input type="text" placeholder="Enter Name" name="name" id="name" v-model="restaurant.name">
    <input type="text" placeholder="Enter Address" name="address" id="address" v-model="restaurant.address">
    <input type="text" placeholder="Enter Contact" name="contact" id="contact" v-model="restaurant.contact">
    <button type="button" v-on:click="addRestaurant">Add New Restaurant</button>
</form>

</template>
<script>
import axios from "axios";
import Header from "./Header.vue";


export default {
    name:'Add-res',
    components:{
        Header
    },
    data(){
        return {
            restaurant:{
                name:'',
                address:'',
                contact:''
            }
        }
    },
    methods:{
        async  addRestaurant(){
            const result  =  await axios.post("http://localhost:3000/restaurant",{
                ...this.restaurant
            })    
            if(result.status==201){
                this.$router.push({name:'Home'})
            }
        }
    },
    mounted(){
        let user = localStorage.getItem('user-info')
        if(!user){
            this.$router.push({name:'SignUp'})
        }
    }
}
</script>
<style>

</style>