<template>
<div class="nav">
  <router-link to="/">Home</router-link>
  <router-link to="add">Add Restaurant</router-link>
  <router-link to="update">Update Restaurant</router-link>
  <a v-on:click="logout">Logout</a>
</div>
</template>

<script>
    export default {
        name:'Header-Component',
        methods:{
            logout(){
                localStorage.removeItem('user-info')
                this.$router.push({name:'Login'})
            }
        }
    }
</script>

<style>
.nav{
    background-color: #333;
    overflow: hidden;

}
.nav  a{
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 10px 14px;
    text-decoration: none;
    font-size: 16px;
    margin-right: 4px;
}
.nav a:hover{
    background-color: #ddd;
    color: #222;
}
</style>