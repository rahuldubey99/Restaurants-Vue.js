<template>
    <Header />
    <h1>Hello {{ name }}, Welcome on Home Page</h1>
    <table border="1">
        <tr>
            <td>ID</td>
            <td>Name</td>
            <td>Address</td>
            <td>Contact</td>
            <td>Actions</td>
        </tr>
        <tr v-for="item in restaurants" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.address }}</td>
            <td>{{ item.contact }}</td>
            <td>
                <router-link :to="`/update/` + item.id">Update</router-link>
                &nbsp; <button type="button" v-on:click="deleteRestaurant(item.id)">Delete</button>
            </td>
        </tr>
    </table>
</template>
<script>
import Header from './Header.vue';
import axios from 'axios';

export default {
    name: 'HomePage',
    data() {
        return {
            name: '',
            restaurants: [],
        }
    },
    components: {
        Header
    },
    methods: {
        async deleteRestaurant(id) {
            let res = await axios.delete("http://localhost:3000/restaurant/"+id)
            if(res.status==200){
                this.loadData()
            }
        },
        async loadData() {
            let user = localStorage.getItem('user-info')
            this.name = JSON.parse(user).name
            if (!user) {
                this.$router.push({ name: 'SignUp' })
            }

            let result = await axios.get("http://localhost:3000/restaurant")
            this.restaurants = result.data
        }
    },
     mounted() {
        this.loadData()
    }
}
</script>

<style>
td {
    width: 160px
}
</style>