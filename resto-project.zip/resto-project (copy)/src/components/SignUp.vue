<template>
    <img class="logo" src="../assets/logo.png" alt="">
    <h1>SignUp</h1>
    <div class="register">
        <input type="text" name="name" id="name" v-model="name" placeholder="Enter Name">
        <input type="text" name="email" id="email" v-model="email" placeholder="Enter email">
        <input type="password" name="password" id="password" v-model="password" placeholder="Enter password">
        <button v-on:click="signUp">SignUp</button>
    </div>
</template>
<script>
import axios from "axios";
export default {
    name:'SignUp',
    data(){
        return {
            name:'',
            email:'',
            password:''
        }
    },
    methods:{
        async signUp(){

            console.log("signUo", this.name, this.email, this.password);
            let res  = await axios.post('http://localhost:3000/users',{
                name: this.name,
                email: this.email,
                password:this.password
            })
            console.log("res", res);
            if(res.status==201){
                alert(res)
                localStorage.setItem('user-info',JSON.stringify(res.data))
                this.$router.push({
                    name:'Home'
                })
            }
        }
    },
    mounted(){
        let user = localStorage.getItem('user-info')
        if(user){
            this.$router.push({name:'Home'})
        }
    }
}

</script>

<style>
.logo{
    width: 100px;
}
.register input{
    width: 300px;
    height: 40px;
    padding-left: 20px;
    display: block;
    margin-bottom: 30px;
    margin-left: auto;
    margin-right: auto;
    border: 1px solid skyblue;

}
.register button{
    width: 320px;
    height: 40px;
    border: 1px solid skyblue;
    color: #fff;
    background-color: skyblue;
    cursor: pointer;
}
</style>