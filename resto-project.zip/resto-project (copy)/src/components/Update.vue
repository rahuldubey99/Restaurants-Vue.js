<template>
    <Header />
    <h1>Hello User, Welcome on Update Restaurant Page </h1>
    <form class="add">
        <input type="text" placeholder="Enter Name" name="name" id="name" v-model="restaurant.name">
        <input type="text" placeholder="Enter Address" name="address" id="address" v-model="restaurant.address">
        <input type="text" placeholder="Enter Contact" name="contact" id="contact" v-model="restaurant.contact">
        <button type="button" v-on:click="updateRestaurant">Add New Restaurant</button>
    </form>
</template>
<script>
import axios from "axios";
import Header from "./Header.vue";

export default {
    name: 'Update-res',
    components: {
        Header
    },
    data() {
        return {
            restaurant: {
                name: '',
                address: '',
                contact: ''
            }
        }
    },
    methods: {
        async updateRestaurant() {
            const result = await axios.put("http://localhost:3000/restaurant/"+this.$route.params.id, {
                ...this.restaurant
            })
            if (result.status == 200) {
                this.$router.push({ name: 'Home' })
            }
        }
    },
    async mounted() {
        let user = localStorage.getItem('user-info')
        if (!user) {
            this.$router.push({ name: 'SignUp' })
        }
        const result = await axios.get("http://localhost:3000/restaurant/"+this.$route.params.id)
            if (result.status == 200) {
                this.restaurant = result.data
            }
    }
}
</script>
<style></style>